package com.amishgarg.wartube.ViewModels

import androidx.lifecycle.ViewModel

class NewPostViewModel : ViewModel(){

}