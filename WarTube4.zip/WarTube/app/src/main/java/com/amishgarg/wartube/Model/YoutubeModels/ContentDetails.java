package com.amishgarg.wartube.Model.YoutubeModels;

public class ContentDetails {
}
