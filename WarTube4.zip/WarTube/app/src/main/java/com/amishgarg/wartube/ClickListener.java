package com.amishgarg.wartube;

public interface ClickListener {

    void onPositionClicked(int position);
}
